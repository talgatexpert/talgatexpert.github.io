<?php
$_['heading_title']    = '<b>#FX Sitemap 4</b>';
$_['text_module']      = 'Модули';
$_['text_edit']        = 'Настройки';
$_['text_success']        = 'Сохранено';
$_['text_modules']        = 'Модули';
$_['text_defalt']        = 'Параметры по умолчанию';
$_['text_key']        = 'Ключ защиты генерации файлов';
$_['produsts']        = 'Товары';
$_['categories']        = 'Категории';
$_['brands']        = 'Производители';
$_['other']        = 'Прочее';
$_['status']        = 'Статус';
$_['service']        = 'Сервис';
$_['text_only_seo_url']        = 'Только с ЧПУ';
$_['text_postfix']        = 'Окончание ЧПУ';
$_['text_sort']        = 'Сортировка';
$_['information']        = 'Инфостраницы';